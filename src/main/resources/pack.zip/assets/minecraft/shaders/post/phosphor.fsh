#version 150

uniform sampler2D InSampler;
uniform sampler2D LastSampler;

in vec2 texCoord;
in vec2 oneTexel;
uniform float GameTime;

uniform vec2 InSize;

out vec4 fragColor;

int decodeInt(vec4 color)
{
    ivec4 col = ivec4(color * 255);
    return col.r * 0x10000 + col.g * 0x100 + col.b;
}

vec3 hue(float h)
{
    float r = abs(h * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(h * 6.0 - 2.0);
    float b = 2.0 - abs(h * 6.0 - 4.0);
    return clamp(vec3(r,g,b), 0.0, 1.0);
}

vec3 HSVtoRGB(vec3 hsv) {
    return ((hue(hsv.x) - 1.0) * hsv.y + 1.0) * hsv.z;
}

vec3 RGBtoHSV(vec3 rgb) {
    vec3 hsv = vec3(0.0);
    hsv.z = max(rgb.r, max(rgb.g, rgb.b));
    float min = min(rgb.r, min(rgb.g, rgb.b));
    float c = hsv.z - min;

    if (c != 0.0)
    {
        hsv.y = c / hsv.z;
        vec3 delta = (hsv.z - rgb) / c;
        delta.rgb -= delta.brg;
        delta.rg += vec2(2.0, 4.0);
        if (rgb.r >= hsv.z) {
            hsv.x = delta.b;
        } else if (rgb.g >= hsv.z) {
            hsv.x = delta.r;
        } else {
            hsv.x = delta.g;
        }
        hsv.x = fract(hsv.x / 6.0);
    }
    return hsv;
}

float random (vec2 st) {
    return fract(sin(dot(st.xy,
                         vec2(12.9898,78.233)))*
        43758.5453123);
}

void main() {

    if (floor(texture(InSampler, vec2(0)) * 255) != vec4(254, 253, 254, 255))
    {
        fragColor = texture(InSampler, texCoord);
        return;
    }

    vec4 color = texture(InSampler, texCoord + vec2(sin(texCoord.x * 100 + GameTime*5000), cos(texCoord.y * 100 + GameTime*5000)) * 0.01);

    vec3 hsv = RGBtoHSV(color.rgb);
    hsv.r = fract(hsv.r + random(hsv.rg) * 100 * GameTime);

    fragColor = vec4(HSVtoRGB(hsv), 1.0);
}
