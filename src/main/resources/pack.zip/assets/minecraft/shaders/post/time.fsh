#version 150

uniform sampler2D InSampler;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

int decodeInt(vec4 color)
{
    ivec4 col = ivec4(color * 255);
    return col.r * 0x10000 + col.g * 0x100 + col.b;
}

vec4 encodeInt(int val)
{
    return vec4(val / 0x10000 % 0x100, val / 0x100 % 0x100, val % 0x100, 255) / 255;
}

void main(){
    int val = decodeInt(texelFetch(InSampler, ivec2(0), 0));
    fragColor = encodeInt(val + 1);
}
