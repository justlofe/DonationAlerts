#version 150

#moj_import <minecraft:fog.glsl>
#define VERT_A 100000

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform float GameTime;
uniform vec4 FogColor;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
flat in int custom;

in vec2 coord;
in vec3 glPos;
in vec4 p1, p2, p3, p4;

out vec4 fragColor;


void writeDepth(vec3 Pos)
{
    vec4 ProjPos = ProjMat * ModelViewMat * vec4(Pos, 1);
    gl_FragDepth = ProjPos.z / ProjPos.w * 0.5 + 0.5;
}

vec2 sphIntersect( in vec3 ro, in vec3 rd, in vec3 ce, float ra )
{
    vec3 oc = ro - ce;
    float b = dot( oc, rd );
    float c = dot( oc, oc ) - ra*ra;
    float h = b*b - c;
    if( h<0.0 ) return vec2(-1.0); // no intersection
    h = sqrt( h );
    return vec2( -b-h, -b+h );
}

void main() {
    gl_FragDepth = gl_FragCoord.z;
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a < 0.1) {
        discard;
    }

    if (floor(color.a * 255) != 254 && custom != 1)
        color *= vertexColor * ColorModulator;

    if (custom == 2 || custom == 3)
    {
        vec3 Pos1 = round(p1.xyz * VERT_A / p1.w) / VERT_A;
        vec3 Pos2 = round(p3.xyz * VERT_A / p3.w) / VERT_A;
        vec3 Pos3 = gl_PrimitiveID % 2 == 0 ? round(p2.xyz * VERT_A / p2.w) / VERT_A : round(p4.xyz * VERT_A / p4.w) / VERT_A;

        vec3 ro = -(Pos1 + Pos2) * 0.5;
        float size = length(Pos1 - Pos3) * 0.15;

        vec3 rd = normalize(glPos);

        vec2 sph = sphIntersect(ro, rd, vec3(0), size);
        if (sph.x == -1)
        {
            //Raymarch depth
            float z = 0,
            //Step distance
            d = 0,
            //Raymarch iterator
            i = 0;

            color = vec4(0, 0, 0, 0);

            //Clear fragColor and raymarch 20 steps
            for(color*=i; i++<2e1; )
            {
                //Sample point (from ray direction)
                // vec3 p = z*normalize(vec3(coord * 1000, 1))+1;
                vec3 p = z*normalize(vec3(coord - vec2(0.03), 1))+1;
                
                //Polar coordinates and additional transformations
                p = vec3(atan(p.y/.2,p.x)*2., p.z/3., length(p.xy)-5.-z*.2);
                
                //Apply turbulence and refraction effect
                for(d=0.; d++<7.;)
                    p += sin(p.yzx*d+GameTime*1000+.3*i)/d;
                    
                //Distance to cylinder and waves with refraction
                z += d = length(vec4(.4*cos(p)-.4, p.z));
                
                //Coloring and brightness
                color += (1.+cos(p.x+i*.4+z+vec4(6,1,2,0)))/d;
            }
            //Tanh tonemap
            color = tanh(color*color/4e2);
            
            color = mix(color, (custom == 2 ? vec4(0, 0, 0, 1) : vec4(1, 1, 1, 1)), smoothstep(0.78, 0.85, 1 - length(coord)*0.5));

            color.a *= smoothstep(0.5, 0.6, 1 - length(coord)*0.5);
        }
        else
        {
            writeDepth(rd * sph.x);
            color = (custom == 2 ? vec4(0, 0, 0, 1) : vec4(1, 1, 1, 1));
        }
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
