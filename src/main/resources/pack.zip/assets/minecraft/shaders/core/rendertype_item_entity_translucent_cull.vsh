#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
flat out int custom;

out vec2 coord;
out vec3 glPos;
out vec4 p1, p2, p3, p4;

void main() {
    vec4 Pos = vec4(Position, 1);
    gl_Position = ProjMat * ModelViewMat * Pos;
    

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;

    vec4 testColor = floor(texture(Sampler0, UV0) * 255);

    const vec2[4] corners = vec2[4](vec2(0), vec2(0, 1), vec2(1), vec2(1, 0));
    vec2 corner = corners[gl_VertexID % 4];
    coord = corner * 2 - 1;

    custom = 0;

    if (testColor == vec4(254, 253, 255, 255) || testColor == vec4(254, 253, 254, 255)) //Effect marker
    {
        custom = 1;
        gl_Position = vec4((corner * vec2(1, -1) * 2 + vec2(0, 2)) / ScreenSize - 1, 0.1, 1);
    }
    else if (testColor == vec4(253, 253, 255, 255) || testColor == vec4(252, 253, 255, 255)) //Effect marker
    {
        custom = testColor == vec4(253, 253, 255, 255) ? 2 : 3;
        p1 = p2 = p3 = p4 = vec4(0);
        switch (gl_VertexID % 4)
        {
            case 0:
                p1 = Pos;
                break;
            case 1:
                p2 = Pos;
                break;
            case 2:
                p3 = Pos;
                break;
            case 3:
                p4 = Pos;
                break;
        }
        glPos = Position;
    }
}
