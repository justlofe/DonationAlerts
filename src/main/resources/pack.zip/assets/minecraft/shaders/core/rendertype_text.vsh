#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 Color0;

out vec2 p1;
out vec2 p2;
out vec2 coord;
flat out int vert;
flat out int p;

const vec2[] offsets = vec2[](
    vec2(0, 0.1),
    vec2(0, 0.2),
    vec2(-0.12, 0.5),
    vec2(0, 0.4),
    vec2(-0.15, 0.75),
    vec2(0, 0.1),
    vec2(-0.06, 0.6),
    
    vec2(0.08, 0.5),

    vec2(0.05, 0.8),
    vec2(0, 0.2),
    vec2(0.1, 0.25),
    vec2(0.16, 0.32),
    vec2(0.2, 0.6),
    vec2(0, 0.53),
    vec2(0, 0.8)
);

void main() {
    vec4 vertex = vec4(Position, 1.0);
    if (Color.xyz == vec3(251, 255, 255) / 255)
    {
        gl_Position = ProjMat * ModelViewMat * vertex;
        vertexColor = vec4(1);
    } else if (Color.xyz == vec3(62, 63, 63) / 255)
    {
        gl_Position = vec4(0);
        return;
    }
    else if (Color.xyz == vec3(255., 254., 253.) / 255.) {
        vertex.xy += 1;
        gl_Position = ProjMat * ModelViewMat * vertex;
    }
    else {
        gl_Position = ProjMat * ModelViewMat * vertex;
        vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    }

    vertexDistance = length((ModelViewMat * vertex).xyz);
    texCoord0 = UV0;
    Color0 = Color;

    // donation font adjustment for correct display
    ivec3 integerColor = ivec3(Color.xyz * 255);

    if(integerColor.x == 4 && integerColor.y == 4) {
        // reset color
        vertexColor.rgb = texelFetch(Sampler2, UV2 / 16, 0).rgb;
        
        int index = integerColor.z / 4;
        float adjustment = float(index - 8) / 8 * -0.5; // (1 to 15) to (-7 to 7) (with floats) and to (-1 to 1)

        vec2 pixelSize = vec2(ProjMat[0][0], ProjMat[1][1]);
        vec2 screenSizeFactor = pixelSize * ScreenSize / vec2(3.2, -3.6); // proportions on screen sizes for 16/9

        vec2 offset = offsets[index - 1];

        float guiScale = abs(ProjMat[1][1]) * ScreenSize.y / 4;

        gl_Position.x += (offset.x + adjustment) * screenSizeFactor.x;
        gl_Position.y += (offset.y * screenSizeFactor.y) - 0.5 * guiScale;
        gl_Position.w *= 0.6 * guiScale;
        return;
    }
    else if(integerColor.x == 1 && (integerColor.y == 1 || integerColor.y == 2)) {
        gl_Position = vec4(2,2,2,1);
        return;
    }
    // end

    if(	Position.z == 0.0 && // check if the depth is correct (0 for gui texts)
			gl_Position.x >= 0.94 && gl_Position.y >= -0.35 && // check if the position matches the sidebar
			vertexColor.g == 84.0/255.0 && vertexColor.g == 84.0/255.0 && vertexColor.r == 252.0/255.0 && // check if the color is the sidebar red color
			gl_VertexID <= 3 // check if it's the first character of a string !! if you want two characters removed replace '3' with '7'
		) gl_Position = ProjMat * ModelViewMat * vec4(ScreenSize + 100.0, 0.0, 0.0);

    p1 = p2 = vec2(0);
    vert = gl_VertexID % 4;

    const vec2[4] corners = vec2[4](vec2(0), vec2(0, 1), vec2(1), vec2(1, 0));
    coord = corners[vert];

    if (vert == 0) p1 = UV0 * 256;
    if (vert == 2) p2 = UV0 * 256;

    p = 0;
    

    float alpha = round(texture(Sampler0, UV0).a * 255);

    if (alpha == 252)
        p = 1;
    else if (alpha == 251)
        p = int(round(texture(Sampler0, UV0).b * 255));
    else if (alpha == 5)
        p = 32;

    if (p != 0 && Position.z > 0)
    {   
        texCoord0 = vec2(UV0 - coord * 56 / 256);

        gl_Position.xy = vec2(coord * 2 - 1) * vec2(1, -1);
        gl_Position.zw = vec2(-1, 1);
        vertexColor = Color;
    }
}
